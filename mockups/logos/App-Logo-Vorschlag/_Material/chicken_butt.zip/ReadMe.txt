Chicken Butt is a TrueType Font By Tom Ledin of Tom Ledin.com


Visit my site:  TomLedin.com


Terms & Conditions of Use:

1.) Chicken Butt is completely free for personal use* and may not be used commercially**. 

2.) The distribution of this font for financial gain or profit is not permitted under any circumstances 
and is strictly prohibited. 

3.) Do not add this font to a font CD or compilation or archive that is to be sold for a profit. 
     If you want to do that, please contact me.  I'm a reasonable person.

4.) *Personal use; however, does not mean "public domain." Chicken Butt may not be 
altered or used to make new/derivative fonts. 

**If you are interested in using Chicken Butt within business or commercial endeavors or 
otherwise outside the realm of "personal use," Contact me, Tom Ledin, tom@tomledin.com
for information on obtaining a liscence to use  Chicken Butt commercially..

Visit my site for my hundreds of Free Photoshop Brushes, and other stupud stuff.


Thanks,

tom



