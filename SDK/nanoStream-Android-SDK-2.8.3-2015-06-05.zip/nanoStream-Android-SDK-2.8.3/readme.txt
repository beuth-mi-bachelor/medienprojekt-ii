nanoStream Live Video Encoding SDK for Android
(c) 2014-2015 nanocosmos gmbh
http://www.nanocosmos.de

Evaluation Usage allowed for 30 days. 
Commercial usage requires a license agreement with nanocosmos gmbh.

Contact us for further information, sample source code, support or consulting:

sales@nanocosmos.de

